import React, { PropTypes } from 'react';
import '../App.css';

const Header = () => {
    return (
        <header className="header">
            <p className="title">React Training</p>
        </header>
    );
}


export default Header;