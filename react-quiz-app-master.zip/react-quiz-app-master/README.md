# react-quiz-app
A simple quiz app coded using reactjs, webpack

![alt text](http://i.imgur.com/SVBU1DN.png "Showing Quiz Questions")

![alt text](http://i.imgur.com/Ta6GFxS.png "Result Screen")

![alt text](http://i.imgur.com/7zC5Dnp.png "Show solutions screen")


### Status
Will work on randomise the questions

###### Thanks, ######
__*Navdeep Singh*__


